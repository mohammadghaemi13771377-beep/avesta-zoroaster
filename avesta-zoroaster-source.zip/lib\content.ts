export const navItems = [
  { label: "خانه", href: "/" },
  { label: "اوستا", href: "/avesta" },
  { label: "جهان", href: "/world" },
  { label: "زرتشت", href: "/zoroaster" },
  { label: "دین زرتشتی", href: "/zoroastrianism" },
  { label: "کتابخانه", href: "/library" },
  { label: "رسانه", href: "/media" },
  { label: "مقاله‌ها", href: "/articles" },
  { label: "فروشگاه", href: "/shop" },
  { label: "گاه‌شمار", href: "/calendar" },
  { label: "کلکسیون‌ها", href: "/collections" },
  { label: "مسیر شخصی", href: "/journey-builder" },
  { label: "برنامه مطالعه", href: "/study-plan" },
  { label: "تایم‌لاین", href: "/timeline" }
];

export const routeMap = [
  "/",
  "/fa",
  "/en",
  "/avesta",
  "/avesta/yasna",
  "/avesta/gathas",
  "/avesta/visperad",
  "/avesta/vendidad",
  "/avesta/yashts",
  "/avesta/khordeh-avesta",
  "/avesta/hats",
  "/world",
  "/zoroaster",
  "/gathas",
  "/zoroastrianism",
  "/monotheism",
  "/newsletter",
  "/newsletter/archive",
  "/newsletter/html-export",
  "/newsletter/preferences",
  "/newsletter/preview",
  "/cyrus",
  "/citations",
  "/calendar",
  "/campaigns",
  "/collections",
  "/concept-map",
  "/dictionary",
  "/journey-builder",
  "/ai-studio",
  "/quests",
  "/reflection",
  "/search",
  "/reading-room",
  "/trust-center",
  "/wisdom-guide",
  "/study-plan",
  "/timeline",
  "/shop",
  "/shop/checkout",
  "/shop/payment/demo",
  "/admin",
  "/admin/go-live",
  "/admin/page-quality",
  "/admin/product-analytics",
  "/admin/team-handoff",
  "/admin/inventory",
  "/admin/production",
  "/admin/production/briefs",
  "/admin/production/review",
  "/admin/visual-assets",
  "/admin/source-review",
  "/admin/avesta",
  "/admin/articles",
  "/admin/calendar",
  "/admin/editorial",
  "/admin/glossary",
  "/admin/library",
  "/admin/media",
  "/admin/newsletter",
  "/admin/newsletter/analytics",
  "/admin/newsletter/experiments",
  "/admin/newsletter/send-times",
  "/admin/newsletter/schedule",
  "/admin/newsletter/delivery",
  "/admin/shop",
  "/admin/import",
  "/admin/seo",
  "/library",
  "/library/archive",
  "/memory",
  "/media",
  "/articles",
  "/login",
  "/register",
  "/profile",
  "/about"
];

export const introCards = [
  {
    title: "اوستا چیست؟",
    description: "دروازه‌ای به متن‌های بنیادین، نیایش‌ها، حکمت و جهان‌بینی ایران باستان.",
    href: "/avesta",
    atmosphere: "scene-fire"
  },
  {
    title: "زرتشت کیست؟",
    description: "پیام‌آور خرد، راستی و انتخاب آگاهانه میان روشنایی و تاریکی.",
    href: "/zoroaster",
    atmosphere: "scene-prophet"
  },
  {
    title: "گات‌ها چیست؟",
    description: "کهن‌ترین سروده‌های منسوب به زرتشت؛ متن‌هایی برای اندیشه، اخلاق و معنا.",
    href: "/gathas",
    atmosphere: "scene-sunrise"
  },
  {
    title: "اهورامزدا",
    description: "نماد دانایی، روشنایی و نظم اخلاقی در قلب آموزه‌های زرتشتی.",
    href: "/zoroastrianism",
    atmosphere: "scene-cosmic"
  }
];

export const avestaSections = [
  {
    title: "یسنا",
    slug: "yasna",
    href: "/avesta/yasna",
    description: "نیایش‌ها، هوم‌ها و آیین‌های بنیادین؛ جایی که آتش، سرود و روشنایی به هم می‌رسند.",
    atmosphere: "scene-fire",
    roman: "I"
  },
  {
    title: "گات‌ها",
    slug: "gathas",
    href: "/avesta/gathas",
    description: "سرودهای ژرف و روشن زرتشت؛ آرام، الهی و سرشار از معنا.",
    atmosphere: "scene-sunrise",
    roman: "II"
  },
  {
    title: "ویسپرد",
    slug: "visperad",
    href: "/avesta/visperad",
    description: "متن آیینی برای تکمیل نیایش‌ها و بزرگداشت همه ردان و نیروهای نیک.",
    atmosphere: "scene-tablets",
    roman: "III"
  },
  {
    title: "وندیداد",
    slug: "vendidad",
    href: "/avesta/vendidad",
    description: "قانون، پاکی و رازهای تاریک‌تر اوستا در فضایی پرهیبت و رمزآلود.",
    atmosphere: "scene-stone",
    roman: "IV"
  },
  {
    title: "یشت‌ها",
    slug: "yashts",
    href: "/avesta/yashts",
    description: "سرودهای حماسی برای ایزدان، طبیعت، آسمان، آب، مهر و پیروزی.",
    atmosphere: "scene-mountain",
    roman: "V"
  },
  {
    title: "خرده اوستا",
    slug: "khordeh-avesta",
    href: "/avesta/khordeh-avesta",
    description: "نیایش‌های روزانه، آرامش شخصی و حضور روشنایی در زندگی معمول.",
    atmosphere: "scene-scroll",
    roman: "VI"
  },
  {
    title: "هات‌ها",
    slug: "hats",
    href: "/avesta/hats",
    description: "نقشه مطالعه، طومار فصل‌ها و مسیر ورود به متن‌های جزءبه‌جزء.",
    atmosphere: "scene-portrait",
    roman: "VII"
  }
];

export const featuredArticles = [
  "اشا؛ نظم راستی در جهان زرتشتی",
  "فروهر در هنر و اندیشه ایران باستان",
  "گات‌ها و پیام اخلاقی برای انسان امروز"
];
