# فهرست فایل‌های پروژه

این manifest برای تحویل سریع به تیم فنی است.

## Root

- `.env.example`: نمونه متغیرهای محیطی
- `README.md`: راهنمای اصلی پروژه
- `DELIVERY.md`: نقطه شروع بسته تحویل
- `package.json`: dependencyها و scriptها
- `next.config.mjs`: تنظیمات Next.js
- `tailwind.config.ts`: تنظیمات Tailwind
- `tsconfig.json`: تنظیمات TypeScript
- `middleware.ts`: محافظ مسیرهای profile و admin
- `preview-server.mjs`: سرور سبک برای `local-preview.html`
- `local-preview.html`: پیش‌نمایش static
- `avesta-zoroaster-source.zip`: فایل دانلودی کل پروژه

## app

- `app/page.tsx`: صفحه خانه
- `app/layout.tsx`: layout اصلی
- `app/globals.css`: استایل global
- `app/avesta`: پورتال و صفحات اوستا
- `app/articles`: مقاله‌ها
- `app/dictionary`: واژه‌نامه
- `app/library`: کتابخانه
- `app/media`: رسانه
- `app/search`: جستجو
- `app/timeline`: تایم‌لاین
- `app/profile`: پروفایل مطالعه
- `app/admin`: پنل مدیریت
- `app/api`: API routes
- `app/sitemap.ts`: sitemap داینامیک
- `app/robots.ts`: robots داینامیک

## components

- `components/header.tsx`: هدر اصلی
- `components/footer.tsx`: فوتر
- `components/section-card.tsx`: کارت بخش‌ها
- `components/search-panel.tsx`: پنل جستجو
- `components/resource-explorer.tsx`: مرور منابع
- `components/reading-controls.tsx`: کنترل حالت مطالعه
- `components/articles-explorer.tsx`: فیلتر مقاله‌ها
- `components/admin`: کامپوننت‌های پنل ادمین
- `components/auth`: فرم‌های ورود و خروج

## lib

- `lib/content.ts`: محتوای ساختاری نمونه
- `lib/sample-content.ts`: داده‌های نمونه صفحات
- `lib/avesta-repository.ts`: خواندن اوستا از Prisma یا fallback
- `lib/media-repository.ts`: خواندن و ذخیره رسانه
- `lib/admin-content.ts`: قرارداد ذخیره محتوای ادمین
- `lib/bulk-import.ts`: ورود دسته‌ای محتوا
- `lib/admin-stats.ts`: آمار داشبورد ادمین
- `lib/search.ts`: جستجوی نمونه
- `lib/i18n.ts`: چندزبانه
- `lib/prisma.ts`: Prisma client
- `lib/auth.ts`: auth demo
- `lib/upload-storage.ts`: ذخیره فایل آپلودی
- `lib/ai-prompts.ts`: پرامپت‌های AI

## prisma

- `prisma/schema.prisma`: مدل دیتابیس
- `prisma/seed.js`: seed اولیه

## public

- `public/images/avesta-zoroaster-logo.png`: لوگوی اصلی
- `public/images/ai`: جایگاه تصاویر AI
- `public/audio`: جایگاه صوت
- `public/library`: جایگاه PDF
- `public/video`: جایگاه ویدیو

## docs

- `docs/technical-handoff.md`
- `docs/product-design-handoff.md`
- `docs/local-preview-and-deploy.md`
- `docs/content-intake-guide.md`
- `docs/bulk-import-guide.md`
- `docs/media-asset-plan.md`
- `docs/ai-prompt-library.md`
- `docs/search-meilisearch-plan.md`
- `docs/implementation-roadmap.md`
- `docs/project-brief.md`
- `docs/auth-plan.md`
- `docs/i18n-plan.md`
- `docs/user-profile-data-model.md`
- `docs/avesta-data-flow.md`
