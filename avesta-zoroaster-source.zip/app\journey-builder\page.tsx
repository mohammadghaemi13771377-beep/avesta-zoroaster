import type { Metadata } from "next";
import { CinematicHub } from "@/components/cinematic-hub";
import { JourneyBuilderPanel } from "@/components/journey-builder-panel";
import { getJourneyBuilderStats, normalizeJourneyInput } from "@/lib/journey-builder";

export const metadata: Metadata = {
  title: "سازنده مسیر شخصی | AVESTA-ZOROASTER",
  description: "Journey Builder برای ساخت مسیر شخصی مطالعه، نیایش، رسانه و کردار روزانه در جهان اوستا.",
};

export default function JourneyBuilderPage() {
  return (
    <CinematicHub
      eyebrow="Journey Builder"
      title="مسیر شخصی خودت در جهان اوستا را بساز"
      lead="به‌جای اینکه کاربر میان ده‌ها بخش گم شود، این ابزار بر اساس نیت، زمان، سطح و سبک تجربه، یک مسیر زنده و قابل ادامه پیشنهاد می‌دهد."
      scene="scene-sunrise"
      roman="J"
      actions={[
        { label: "شروع ساخت مسیر", href: "#builder" },
        { label: "برنامه ۷ روزه", href: "/study-plan", variant: "secondary" },
      ]}
      stats={getJourneyBuilderStats()}
    >
      <div id="builder" className="scroll-mt-28">
        <JourneyBuilderPanel initialInput={normalizeJourneyInput()} />
      </div>
    </CinematicHub>
  );
}
